import React from "react";

export const Login = () => {
  return (
    <div>
      <h1>Login Page</h1>
      <form>
        <input type="text" className="Name" />
      </form>
    </div>
  );
};
